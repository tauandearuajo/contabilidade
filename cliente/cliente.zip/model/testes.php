<?php 


$teste = $_FILES['padlock_password']['name'];
echo ''. $teste .'';